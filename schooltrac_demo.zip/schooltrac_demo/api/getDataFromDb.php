<?php

//header('Content-Type: text/plain; charset="UTF-8"');
 header('Content-Type: application/json');
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);

function getData($data)
{
 //start get a list of database
$limit = mysql_real_escape_string($data['limit']);

        $ch = curl_init();
//       $limit = $_GET['limit'];
        //curl_setopt($ch, CURLOPT_URL, 'http://127.0.0.1:5984/customers/_all_docs');
//        curl_setopt($ch, CURLOPT_URL, 'https://3bce0f18-edfb-4e7d-970b-6fa3b7e792f0-bluemix.cloudant.com/iotp_o0mfkf_default_2016-10-12/_design/Test_Darren/_view/by%20timestamp?limit='.$limit.'&reduce=false&descending=true');
        curl_setopt($ch, CURLOPT_URL, 'https://3c95e9f7-7770-4510-989f-a4afe583f80f-bluemix.cloudant.com/active_reader_3/_design/by-date/_view/new-view?limit='.$limit.'&reduce=false&descending=true');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//        curl_setopt($ch, CURLOPT_USERPWD, 'theathicatsolderetoinder:30d9501089de142ea30d713a8653ab9393c439e1');
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-type: application/json',
                'Accept: */*'
        ));

        $response = curl_exec($ch);
       // print_r($response);
        $json_de = json_decode($response,TRUE);
        $tempArray = array();
  
        
        for($i = 0; $i<  sizeof($json_de['rows']); $i++){
//            print_r($json_de['rows'][$i]['value']['d']);
            
//            array_push($tempArray,$json_de['rows'][$i]['value']['d']);
            array_push($tempArray,$json_de['rows'][$i]['value']['d']);
        }
//        print_r($tempArray);
//       array_unique( array_merge($tempArray, $tempArray) );
        $details = unique_multidim_array($tempArray,'addr');
//        print_r($details);
        $json_return = array(
            'data'=>$details
        );

        curl_close($ch);
 
        //end get a list of database
//              echo json_encode($json_de);
        return json_encode($json_return);
       
      //  echo $json_de;
      //  return $json_de;
}


function unique_multidim_array($array, $key) { 
    $temp_array = array(); 
    $i = 0; 
    $key_array = array(); 
    
    foreach($array as $val) { 
        if (!in_array($val[$key], $key_array)) { 
            $key_array[$i] = $val[$key]; 
            $temp_array[$i] = $val; 
        } 
        $i++; 
    } 
    return $temp_array; 
} 
?>
