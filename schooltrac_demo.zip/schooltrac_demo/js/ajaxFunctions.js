
function clearLoginTextBoxes()
{    
    document.getElementById("userID").value = "";
}

function setProductBrand(brand){
    localStorage['brand'] = brand;
}

function getProductBrand(){
    return localStorage['brand'];
}


function clearLoginPasswordTextBoxes()
{
    document.getElementById("password").value = ""; 
}

function adminLogin()
{
	var username  = document.getElementById("username").value;
	var password = document.getElementById("password").value;
        
        username = username.replace(/"/g, '\\"');
        password = password.replace(/"/g, '\\"');
        
	var data = '{ "getLogin_data": { "username":"'+username+'", "password":"'+password+'" } } ';
	
	jQuery.ajax({
   		type: "POST",
   		url: "./api.php",
   		data: "data=" + data + "&action=getLogin", 
   		success: function(msg){
			
                
     		var decodedJson = JSON.parse(msg);
     		var success = decodedJson.result;
                var data = decodedJson.data;
                var id = data['login'][0].id;
                
     		if(success==="1")
     		{
                        alert("login success");
                        
                        setSessionVariable(id);
     		}
     		else
     		{
         		alert("The user id or password you have entered is incorrect. Please try again.");
                        location.reload();
     		}
   		},
                error: function (xhr, ajaxOptions, thrownError) {
                    alert(thrownError);
                    
      		}
		});

}
function setSessionVariable(userId)
{
   
	var data = '{"setSession_data" :{  "userId":"' + userId + '"}}';
	jQuery.ajax({
   		type: "POST",
   		url: "./api.php",
   		data: "data=" + data + "&action=setSession",
   		success: function(msg){
       
    		var decodedJson = JSON.parse(msg);
     		var success = decodedJson.result;
     
     		if(success==="1")
     		{
         		window.location = "index.php";             		
     		}
     		else
     		{
     			alert("set session fail :(");
     		}
     		
   		},
      	error: function (xhr, ajaxOptions, thrownError) {
        	
      	}
	});
}

function goBack()
{
//    $("#backForm").submit();
//    $(".pagination-page").pagination('selectPage', pageNumber);
//    $(".pagination-page").selectPage(pageNumber);
    window.history.back();
}

function test(){
    alert("test function!");
}

function test2(id){
    alert(id);
}

function getDataDevices(id,typeId){
            
           var data = encodeURIComponent('{ "getDevices_data": { "customer_id":"'+id+'", "type_id":"'+typeId+'", "device_id":"" } }');
//           alert("12");
           jQuery.ajax({
   		type: "POST",
                url: "./api.php",
                data: "data=" + data + "&action=getDevices",
   		success: function(msg){
                    $('#usertableid').empty();
//                    alert("here22");
                    var decodedJson = JSON.parse(msg);
                    var data = decodedJson.data;
                  
//                  alert(msg);
                    initTableSource(id,data);
                    // var table = '<table class="table"><tr><td>Device Type</td><td>Device ID</td><td>Timestamp</td><td>CPU Temp</td><td>Memory Usage</td><td>Sine</td></tr>';

   		},
                error: function (xhr, ajaxOptions, thrownError) {
                    alert(thrownError);
                    
      		}
		});
        }
        //}, 2000);
        
var limit = 10;
       var allData = [];
       var newAllData = [];
       var locId1Data = [];
       var locId2Data = [];
       var location1 = [];
       var location2 = [];
       var location3 = [];
//        window.setInterval(function(){
function getDataFrom(){
//            alert("here1");
            var data = encodeURIComponent(' { "getData_data": { "customer_id":"1","limit":"'+limit+'" } }');
           jQuery.ajax({
   		type: "POST",
//   		url: "../getDataFromDb.php?limit="+limit,
                url: "./api.php",
                data: "data=" + data + "&action=getData",
   		success: function(msg){
                    
//                    $('#usertableid').empty();
//                    $('#tableLocation1').empty();
//                    $('#tableLocation2').empty();
//                    limit++;
//                    if(limit < 3)
                    initTableSource(msg);
                    // var table = '<table class="table"><tr><td>Device Type</td><td>Device ID</td><td>Timestamp</td><td>CPU Temp</td><td>Memory Usage</td><td>Sine</td></tr>';

   		},
                error: function (xhr, ajaxOptions, thrownError) {
                    limit =0;
                    alert(thrownError);
                    
      		}
		});
        }
//        }, 2000);
        
function initTableSource(data){
    	  if(data.length!=0)
	  {
              table =  $('#usertableid').DataTable();
              table2 =  $('#tableLocation1').DataTable();
              table3 =  $('#tableLocation2').DataTable();
              
              $("#usertableid tbody tr").remove();
              $("#tableLocation1 tbody tr").remove();
              $("#tableLocation2 tbody tr").remove();
              
              
//                allData = [];
//                newAllData = [];
//                locId1Data = [];
//                locId2Data = [];
                
	        // table header
//	    	var header = '<thead><tr><td>Date</td><td>Device ID</td><td>Locator ID</td><td>RSSI</td><td>Battery</td><td>Temperature</td></tr></thead><tbody>';
//	    	
//                var header2 = '<thead><tr><td>Date</td><td>Device ID</td><td>Locator ID</td></thead><tbody>';
//	    	$('#usertableid').append(header);
//                $('#tableLocation1').append(header2);
//                $('#tableLocation2').append(header2);
	    	for(var i = 0; i < data['data'].length; i++)
	    	{
//                    alert(data['data'][i]);
                   // alert("here1");
//                    var date=data['rows'][i].value.d.date;
//                    var device_Id=data['rows'][i].value.d.addr;
//                    var rssi=data['rows'][i].value.d.rssi;
//                    var battery=data['rows'][i].value.d.batt;
//                    var temp=data['rows'][i].value.d.temp;
//                    var locID=data['rows'][i].value.d.locID;
//                    var ip_address=data['rows'][i].value.d.ip_address;

                    var date=data['data'][i].date;
                    var device_Id=data['data'][i].addr;
                    var rssi=data['data'][i].rssi;
                    var battery=data['data'][i].batt;
                    var temp=data['data'][i].temp;
                    var locID=data['data'][i].locID;
                    var ip_address=data['data'][i].ip_address;  
                    
                    if(data['data'][i].date === undefined || data['data'][i].date === null){
                        date = '0';
                     }
                     else{
                         date = data['data'][i].date;
                     }
                     
                     if(data['data'][i].addr === undefined || data['data'][i].addr === null){
                        device_Id = '0';
                     }
                     else{
                         device_Id = data['data'][i].addr;
                     }
                     
                     if(data['data'][i].rssi === undefined || data['data'][i].rssi === null){
                        rssi = '0';
                     }
                     else{
                         rssi = data['data'][i].rssi;
                     }
                     
                     if(data['data'][i].batt === undefined || data['data'][i].batt === null){
                        battery = '0';
                     }
                     else{
                         battery = data['data'][i].batt;
                     }
                     
                     if(data['data'][i].temp === undefined || data['data'][i].temp === null){
                        temp = '0';
                     }
                     else{
                         temp = data['data'][i].temp;
                     }
                     
                     if(data['data'][i].ip_address === undefined || data['data'][i].ip_address === null){
                        ip_address = '0';
                     }
                     else{
                         ip_address = data['data'][i].ip_address;
                     }
                     
                     
                     if(data['data'][i].locID === undefined || data['data'][i].locID === null){
                        locID = '0';
                     }
                     else{
                         locID = data['data'][i].locID;
                     }
                    
                    var inData = '{"date":"'+date+'","deviceId":"'+device_Id+'","rssi":"'+rssi+'","battery":"'+battery+'","temp":"'+temp+'","locId":"'+locID+'"}';
                    var inData2 = [date,device_Id,locID,ip_address,rssi,battery,temp];  
                    var inData3 = [date,device_Id,locID];  
                 
//                 if(allData.length === 0){
                        allData.push(inData2);
//                        limit = allData.length + 1;
//                        alert(limit);
//                    }
//                    else{
//                        checkData(inData2,device_Id);
//                    }
////                        alert(allData[i][1]);
//                        alert("device_id "+i+"="+device_Id);
                        checkData(inData2,device_Id);
                    
//                    else if(allData.length > 0){
////                        alert(allData.length);
//                        for(var j=0;j<allData.length;j++){
////                            alert("length2="+allData.length);
//                                        
////                            alert("data="+allData[j][1]);
////                            alert("data2="+device_Id);
//                            if(allData[j][1] === device_Id){
////                                alert("true");
////                                alert(allData[i].deviceId);
////                                alert(device_Id);
////                                allData.push(inData2);
//                                  allData.splice(j-1,1,inData2);
//                            }
//                            else{
////                                allData.splice(j-1,1,inData2);
////                                alert(allData[j]);
////                                    allData[j] = inData2;
//                            }
////                            allData.push(inData);
////                            alert(allData.length);
//                        }
//                    }
                    
                  
//                    var record = '<tr><td>'+date+'</td><td>'+device_Id+'</td><td>'+locID+'</td><td>'+rssi+'</td><td>'+battery+'</td><td>'+temp+'</td></tr>';
//
//                    $('#usertableid').append(record);
//                    
                    if(locID === 501){
                        locId1Data.push(inData3);
//                    var date2=data['rows'][i].value.data.d.date;
//                    var device_Id2=data['rows'][i].value.data.d.addr;
//                    var rssi2=data['rows'][i].value.data.d.rssi;
//                    var battery2=data['rows'][i].value.data.d.batt;
//                    var temp2=data['rows'][i].value.data.d.temp;
//                    var locID2=data['rows'][i].value.data.d.locID;
//                 
//
//                  
//                    var record2 = '<tr><td>'+date2+'</td><td>'+device_Id2+'</td><td>'+locID2+'</td></tr>';
//
//                    $('#tableLocation1').append(record2);
//                    
//                        
                    }
//                    
                    else if(locID === 502){
                        locId2Data.push(inData3);
//                    var date3=data['rows'][i].value.data.d.date;
//                    var device_Id3=data['rows'][i].value.data.d.addr;
//                    var rssi3=data['rows'][i].value.data.d.rssi;
//                    var battery3=data['rows'][i].value.data.d.batt;
//                    var temp3=data['rows'][i].value.data.d.temp;
//                    var locID3=data['rows'][i].value.data.d.locID;
//                 
//
//                  
//                    var record3 = '<tr><td>'+date3+'</td><td>'+device_Id3+'</td><td>'+locID3+'</td></tr>';
//
//                    $('#tableLocation2').append(record3);
//                    
//                        
                    }
	    	}
//                alert("dev id-"+device_Id);
//                 checkData(inData2,device_Id);
//                alert(allData);
//                alert(locId1Data);
//                alert(locId2Data);
               
	    }
            else
            {
                var header = '<tr><td>No records found!</td><td></tr>';
	    	$('#usertableid').append(header);
            }
            table.destroy();
            table2.destroy();
            table3.destroy();
	    $('#usertableid').DataTable(
                    {
                        data: newAllData,
                        order: [[ 0, "desc" ]],
                        columns: [
                            { title: "Date" },
                            { title: "Device ID" },
                            { title: "Locator ID" },
                            { title: "IP Address" },
                            { title: "RSSI" },
                            { title: "Battery" },
                            { title: "Temperature" }
                        ]
                    });
            $('#tableLocation1').DataTable(
                    {
                        data: locId1Data,
                        order: [[ 0, "desc" ]],
                        columns: [
                            { title: "Date" },
                            { title: "Device ID" },
                            { title: "Locator ID" }
                        ]
                    });
            $('#tableLocation2').DataTable(
                    {
                        data: locId2Data,
                        order: [[ 0, "desc" ]],
                        columns: [
                            { title: "Date" },
                            { title: "Device ID" },
                            { title: "Locator ID" }
                        ]
                    });
}

//        function getDataFromPhp(){
//            $.get('getDataFromDb', null, function(data) {
//              console.log('Server said: ' + data);
//              alert(data);
//            }
//            
//            setInterval(function() {
//            $.get('getDataFromDb', null, function(data) {
//              console.log('Server said: ' + data);
//              alert(data);
//            }
//          }, 5000);
//        }

function checkData(inData2,device_Id){
//    alert("length2="+allData.length);
        var isthere = false;
        var tempData = [];
                for(var j=0;j<allData.length;j++){
                            
                                       
//                            alert("data="+allData[j][1]+" data2="+device_Id);
                            
                            if( device_Id !== allData[j][1]){
//                                alert("in here ll");
                                isthere = false;
//                                allData[j] = inData2;
//                                alert(allData[j][1] +"==="+ device_Id);
//                                alert(allData[i].deviceId);
//                                alert(device_Id);
//                                allData.push(inData2);
//                                  allData.splice(j-1,1,inData2);
//                                   continue;
                            }
                            else{
//                                alert("in here kk");
//                                allData.push(inData2);
                                isthere = true;
                                break;
//                                break;
//                                allData.splice(j-1,1,inData2);
//                                alert(allData[j]);
//                                    allData[j] = inData2;
                            }
//                            allData.push(inData);
//                            alert(allData.length);
         
                        }
//                        alert("isthere="+isthere);
//                        if(newAllData.length === 0){
//                            newAllData.push(inData2);
//                        }
//                 alert("j="+j+"data="+allData[j][1]+" data2="+device_Id+" istrue="+isthere);
                        if(isthere){
                            newAllData[j] = inData2;
                        }
                        else{
                            newAllData.push(inData2);
                        }
//                        alert("alldata="+allData);
//                        alert("newalldata="+newAllData);
                        tempData = cleanArray(newAllData);
                        newAllData = [];
                        newAllData = tempData;
                        
}



function cleanArray(actual) {
  var newArray = new Array();
  for (var i = 0; i < actual.length; i++) {
    if (actual[i]) {
      newArray.push(actual[i]);
    }
  }
  return newArray;
}

function getDataMap(){
//            alert("here1");
            var data = encodeURIComponent(' { "getData_data": { "customer_id":"1","limit":"'+5+'" } }');
           jQuery.ajax({
   		type: "POST",
//   		url: "../getDataFromDb.php?limit="+limit,
                url: "./api.php",
                data: "data=" + data + "&action=getData",
   		success: function(msg){
                    
//                    $('#usertableid').empty();
//                    $('#tableLocation1').empty();
//                    $('#tableLocation2').empty();
//                    limit++;
//                    if(limit < 3)
//                    map.removeLayer(marker);
                    createMap(msg);
                    // var table = '<table class="table"><tr><td>Device Type</td><td>Device ID</td><td>Timestamp</td><td>CPU Temp</td><td>Memory Usage</td><td>Sine</td></tr>';

   		},
                error: function (xhr, ajaxOptions, thrownError) {
                    limit =0;
                    alert(thrownError);
                    
      		}
		});
        }
        
        
        
function createMap(data){
//    var marker;
    if(data.length!=0)
	  {
               location1 = [];
               location2 = [];
               location3 = [];
               
               var temploc1 = [];
               var temploc2 = [];
               var temploc3 = [];

	    	for(var i = 0; i < data['data'].length; i++)
	    	{
                   // alert("here1");
                    var date=data['data'][i].date;
                    var device_Id=data['data'][i].addr;
                    var rssi=data['data'][i].rssi;
                    var battery=data['data'][i].batt;
                    var temp=data['data'][i].temp;
                    var locID=data['data'][i].locID;
                    var ip_address=data['data'][i].ip_address;  
                    
                    if(data['data'][i].date === undefined || data['data'][i].date === null){
                        date = '0';
                     }
                     else{
                         date = data['data'][i].date;
                     }
                     
                     if(data['data'][i].addr === undefined || data['data'][i].addr === null){
                        device_Id = '0';
                     }
                     else{
                         device_Id = data['data'][i].addr;
                     }
                     
                     if(data['data'][i].rssi === undefined || data['data'][i].rssi === null){
                        rssi = '0';
                     }
                     else{
                         rssi = data['data'][i].rssi;
                     }
                     
                     if(data['data'][i].batt === undefined || data['data'][i].batt === null){
                        battery = '0';
                     }
                     else{
                         battery = data['data'][i].batt;
                     }
                     
                     if(data['data'][i].temp === undefined || data['data'][i].temp === null){
                        temp = '0';
                     }
                     else{
                         temp = data['data'][i].temp;
                     }
                     
                     if(data['data'][i].ip_address === undefined || data['data'][i].ip_address === null){
                        ip_address = '0';
                     }
                     else{
                         ip_address = data['data'][i].ip_address;
                     }
                     
                     
                     if(data['data'][i].locID === undefined || data['data'][i].locID === null){
                        locID = '0';
                     }
                     else{
                         locID = data['data'][i].locID;
                     }
                    
                    var inData = '{"date":"'+date+'","deviceId":"'+device_Id+'","rssi":"'+rssi+'","battery":"'+battery+'","temp":"'+temp+'","locId":"'+locID+'"}';
                    var inData2 = [date,device_Id,locID,ip_address,rssi,battery,temp];  
                    var inData3 = [date,device_Id,locID];  
                 
//                 if(allData.length === 0){
                        allData.push(inData2);
//                        limit = allData.length + 1;
//                        alert(limit);
//                    }
//                    else{
//                        checkData(inData2,device_Id);
//                    } 

                    if(locID === 501){
//                        if(rssi >= -50){
//                        location1.push(inData3); 
                        temploc1 = checkDataMap(location1,inData3,device_Id);
                        location1 = [];
                        location1 = temploc1;
//                            }
                    }
                    else if(locID === 502){
//                         if(rssi >= -50){
//                        location2.push(inData3); 
                        temploc2 = checkDataMap(location2,inData3,device_Id);
                        location2 = [];
                        location2 = temploc2;
//                            }
                    }
                    else{
//                        if(rssi >= -50){
//                        location3.push(inData3); 
                        temploc3 = checkDataMap(location3,inData3,device_Id);
                        location3 = [];
                        location3 = temploc3;
//                            }
                    }
	    	}
                
//                alert("loc1 ="+locator1.length+" loc2="+locator2.length+" locator3="+locator3.length);
	    }
 
        var newMarkerGroup = new L.FeatureGroup();
      
        var userOne = false,
          userPin = L.divIcon({
            className: 'user-pin',
            html: '<img src="images/icon/user.png"><div class="pin2"></div>',
            iconSize: [30, 30],
            iconAnchor: [18, 30]
          });
         
//         map.removeLayer(userMark);
//         map.removeLayer(userMark2);
//         map.removeLayer(userMark3);
        for(var i=0;i<location1.length;i++){
//            var userMark;
//            userMark.clearLayers();
           
            var loc1 = {
            x: 1300+getRandomInt(0,300),
            y: 300+getRandomInt(0,500)
          };
          marker = L.marker(map.unproject([loc1.x, loc1.y], map.getMaxZoom()), {
          icon: userPin
        });
         newMarkerGroup.addLayer(marker);
        // Add pop up for click
        marker.bindPopup("<b>"+location1[i][0]+"</b><br><b>"+location1[i][1]+"</b>");
        }
        
        
        for(var i=0;i<location2.length;i++){
//            var userMark2;
//            userMark2.clearLayers();
           
            var loc2 = {
            x: 2500+getRandomInt(0,300),
            y: 300+getRandomInt(0,500)
          };
          marker = L.marker(map.unproject([loc2.x, loc2.y], map.getMaxZoom()), {
          icon: userPin
        });
        newMarkerGroup.addLayer(marker);
        // Add pop up for click
        marker.bindPopup("<b>"+location2[i][0]+"</b><br><b>"+location2[i][1]+"</b>");
        }
        
        
        for(var i=0;i<location3.length;i++){
//            var userMark3;
//            userMark3.clearLayers();
           
            var loc3 = {
            x: 2500+getRandomInt(0,300),
            y: 2000+getRandomInt(0,800)
          };
          marker = L.marker(map.unproject([loc3.x, loc3.y], map.getMaxZoom()), {
          icon: userPin
        });
        newMarkerGroup.addLayer(marker);
        // Add pop up for click
        marker.bindPopup("<b>"+location3[i][0]+"</b><br><b>"+location3[i][1]+"</b>");
        }
        this.map.addLayer(newMarkerGroup);
        
        setTimeout(function(){ 
                newMarkerGroup.clearLayers();
           }, 4500);  

}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function checkDataMap(arrayIn,inData3,device_Id){
    
        var isthere = false;
        var tempData = [];
                for(var j=0;j<arrayIn.length;j++){
                            
                            if( device_Id !== arrayIn[j][1]){
//                                alert("in here ll");
                                isthere = false;
//                                
                            }
                            else{
//                               
                                isthere = true;
                                break;
//                               
                            }
//                           
                        }
//                       
//                 alert("j="+j+"data="+allData[j][1]+" data2="+device_Id+" istrue="+isthere);
                        if(isthere){
                            arrayIn[j] = inData3;
                        }
                        else{
                            arrayIn.push(inData3);
                        }
//                        alert("alldata="+allData);
//                        alert("newalldata="+newAllData);
                        tempData = cleanArray(arrayIn);
                        arrayIn = [];
                        arrayIn = tempData;
                        
                        return arrayIn;
    
}

